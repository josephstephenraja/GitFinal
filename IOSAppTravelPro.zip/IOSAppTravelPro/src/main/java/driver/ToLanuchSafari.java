package driver;

public class ToLanuchSafari {
	
	public static void toLanchSafari() {
		// TODO Auto-generated method stub

	}


}
